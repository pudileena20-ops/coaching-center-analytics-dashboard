# Coaching Center Student Analytics (SQL Server + Power BI)

An end-to-end data analyst project built on **real data** from a coaching center —
tracking student enrollments, attendance, course performance, and fee collection,
visualized in an interactive Power BI dashboard.

## Tech Stack
SQL Server, T-SQL, Power BI, Python (Pandas, for data prep)

## Project Structure
```
coaching_analyst_project/
├── data/                          # place your real data + prepared CSVs here
├── sql/
│   ├── 01_create_schema.sql       # database + table creation
│   ├── 02_load_data.sql           # BULK INSERT of CSVs into tables
│   ├── 03_analysis_queries.sql    # joins, subqueries, window functions
│   └── 04_stored_procedure.sql    # at-risk student report (parameterized)
├── prepare_data.py                # reshapes your raw export into clean CSVs
└── README.md
```

## Setup

### 1. Gather your real data
Get exports from the coaching center covering:
- **Students**: ID, name, gender, contact, city, course, enrollment date
- **Courses**: ID, name, subject, instructor, batch timing, start/end dates
- **Attendance**: student ID, class date, present/absent
- **Fees**: student ID, amount due, amount paid, payment date, status

This can be one messy Excel file or several — doesn't need to be clean yet.

### 2. Prepare the CSVs
```bash
pip install pandas openpyxl
python prepare_data.py --input data/your_raw_export.xlsx --output_dir data/
```
Run it once to see your actual column names printed out, then edit the mapping
section inside `prepare_data.py` to match your real columns, and re-run.
This produces `Students.csv`, `Courses.csv`, `Attendance.csv`, `Fees.csv`.

### 3. Create the database
Open SSMS, connect to your local SQL Server instance, and run:
```
sql/01_create_schema.sql
```

### 4. Load the data
Update the file paths inside `sql/02_load_data.sql`, then run it in SSMS.

### 5. Run the analysis queries
Run `sql/03_analysis_queries.sql` — covers revenue/enrollment by course,
lowest-attendance students (at-risk flagging), pending fees, monthly
enrollment trend, and course attendance ranking.

### 6. Create the stored procedure
Run `sql/04_stored_procedure.sql`, then test it:
```sql
EXEC dbo.GetAtRiskStudents @CourseID = 'CRS-001', @AttendanceThreshold = 75.00;
```

## Building the Power BI Dashboard

1. Open Power BI Desktop → **Get Data** → **SQL Server** → connect to `CoachingCenterDB`
2. Import `Students`, `Courses`, `Attendance`, `Fees`
3. Confirm relationships in **Model view**
4. Build these visuals:
   - **KPI Cards**: Total Students, Total Revenue Collected, Overall Attendance %, Outstanding Fees
   - **Line chart**: Monthly enrollment trend
   - **Bar chart**: Enrollment and revenue by course
   - **Table**: At-risk students (low attendance + pending fees)
5. Add a DAX measure, e.g.:
   ```dax
   Attendance Rate % =
   DIVIDE(
       CALCULATE(COUNTROWS(Attendance), Attendance[Status] = "Present"),
       COUNTROWS(Attendance)
   )
   ```
6. Save and export screenshots for your GitHub README

## Results
_Fill this in after running on your real data, e.g.:_
- Tracked **X** students across **X** courses
- Identified **X** at-risk students with attendance below 75%
- Flagged ₹**X** in outstanding fees for follow-up

## Data Privacy Note
Since this uses real student data, **do not** upload real names, phone numbers,
or other personal details to GitHub. Before publishing:
- Replace real names with anonymized IDs (e.g., "Student 1", "Student 2")
- Remove or mask contact numbers
- Keep only aggregated/anonymized data in any public screenshots or CSVs

## Possible Extensions
- Add a batch-wise instructor performance comparison
- Add year-over-year enrollment growth once you have multiple years of data
- Automate monthly fee-reminder flagging with the stored procedure
