/* ============================================================
   02_load_data.sql
   Loads your real coaching center data (as CSVs) into the tables.

   BEFORE RUNNING:
   1. Get your real data from the coaching center into 4 CSVs matching
      the columns below: Courses.csv, Students.csv, Attendance.csv, Fees.csv
      (Use prepare_data.py to help reshape messy/raw exports into this format.)
   2. Update the file paths to match where you saved the CSVs.
   ============================================================ */

USE CoachingCenterDB;
GO

BULK INSERT Courses
FROM 'C:\CoachingCenterDB\Courses.csv'
WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

BULK INSERT Students
FROM 'C:\CoachingCenterDB\Students.csv'
WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

BULK INSERT Attendance
FROM 'C:\CoachingCenterDB\Attendance.csv'
WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);

BULK INSERT Fees
FROM 'C:\CoachingCenterDB\Fees.csv'
WITH (FIRSTROW = 2, FIELDTERMINATOR = ',', ROWTERMINATOR = '\n', TABLOCK);
GO

-- Sanity checks
SELECT COUNT(*) AS CourseCount FROM Courses;
SELECT COUNT(*) AS StudentCount FROM Students;
SELECT COUNT(*) AS AttendanceRecords FROM Attendance;
SELECT COUNT(*) AS FeeRecords FROM Fees;
GO
