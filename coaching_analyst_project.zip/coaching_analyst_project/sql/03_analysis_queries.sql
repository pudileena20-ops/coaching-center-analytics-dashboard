/* ============================================================
   03_analysis_queries.sql
   Analyst-level queries: joins, subqueries, window functions.
   Run these against CoachingCenterDB once data is loaded.
   ============================================================ */

USE CoachingCenterDB;
GO

-- ------------------------------------------------------------
-- 1. JOIN: Enrollment count and revenue collected per course
-- ------------------------------------------------------------
SELECT
    c.CourseName,
    COUNT(DISTINCT s.StudentID)   AS TotalEnrolled,
    SUM(f.AmountPaid)              AS TotalCollected,
    SUM(f.AmountDue - f.AmountPaid) AS TotalOutstanding
FROM Students s
JOIN Courses c ON s.CourseID = c.CourseID
LEFT JOIN Fees f ON s.StudentID = f.StudentID
GROUP BY c.CourseName
ORDER BY TotalEnrolled DESC;
GO

-- ------------------------------------------------------------
-- 2. SUBQUERY + WINDOW: Attendance % per student, ranked lowest first
--    (useful for flagging at-risk students)
-- ------------------------------------------------------------
SELECT StudentName, AttendancePercent
FROM (
    SELECT
        s.StudentName,
        ROUND(
            SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0
            / NULLIF(COUNT(a.AttendanceID), 0), 2
        ) AS AttendancePercent,
        RANK() OVER (
            ORDER BY SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 1.0
                     / NULLIF(COUNT(a.AttendanceID), 0) ASC
        ) AS LowAttendanceRank
    FROM Students s
    JOIN Attendance a ON s.StudentID = a.StudentID
    GROUP BY s.StudentName
) ranked
WHERE LowAttendanceRank <= 10
ORDER BY AttendancePercent ASC;
GO

-- ------------------------------------------------------------
-- 3. SUBQUERY: Students with fees still pending (outstanding balance)
-- ------------------------------------------------------------
SELECT
    s.StudentName,
    c.CourseName,
    f.AmountDue,
    f.AmountPaid,
    (f.AmountDue - f.AmountPaid) AS Outstanding
FROM Fees f
JOIN Students s ON f.StudentID = s.StudentID
JOIN Courses c ON s.CourseID = c.CourseID
WHERE f.AmountPaid < f.AmountDue
ORDER BY Outstanding DESC;
GO

-- ------------------------------------------------------------
-- 4. WINDOW FUNCTION: Monthly enrollment trend (running total)
-- ------------------------------------------------------------
SELECT
    FORMAT(EnrollmentDate, 'yyyy-MM') AS EnrollmentMonth,
    COUNT(*) AS NewEnrollments,
    SUM(COUNT(*)) OVER (ORDER BY FORMAT(EnrollmentDate, 'yyyy-MM')) AS RunningTotalEnrollments
FROM Students
GROUP BY FORMAT(EnrollmentDate, 'yyyy-MM')
ORDER BY EnrollmentMonth;
GO

-- ------------------------------------------------------------
-- 5. WINDOW FUNCTION: Rank courses by average attendance rate
-- ------------------------------------------------------------
SELECT
    CourseName,
    AvgAttendanceRate,
    RANK() OVER (ORDER BY AvgAttendanceRate DESC) AS AttendanceRank
FROM (
    SELECT
        c.CourseName,
        ROUND(
            SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0
            / NULLIF(COUNT(a.AttendanceID), 0), 2
        ) AS AvgAttendanceRate
    FROM Courses c
    JOIN Students s ON c.CourseID = s.CourseID
    JOIN Attendance a ON s.StudentID = a.StudentID
    GROUP BY c.CourseName
) t
ORDER BY AttendanceRank;
GO

-- ------------------------------------------------------------
-- 6. Fee collection status breakdown
-- ------------------------------------------------------------
SELECT
    PaymentStatus,
    COUNT(*) AS StudentCount,
    SUM(AmountDue) AS TotalDue,
    SUM(AmountPaid) AS TotalPaid
FROM Fees
GROUP BY PaymentStatus
ORDER BY TotalDue DESC;
GO
