/* ============================================================
   01_create_schema.sql
   Coaching Center Student Analytics — Database schema.
   Covers enrollments, courses/batches, attendance, and fee payments.
   ============================================================ */

CREATE DATABASE CoachingCenterDB;
GO

USE CoachingCenterDB;
GO

CREATE TABLE Courses (
    CourseID       VARCHAR(20) PRIMARY KEY,
    CourseName     VARCHAR(100) NOT NULL,
    Subject        VARCHAR(50),
    Instructor     VARCHAR(100),
    BatchTiming    VARCHAR(50),      -- e.g. 'Morning', 'Evening'
    StartDate      DATE,
    EndDate        DATE
);

CREATE TABLE Students (
    StudentID      VARCHAR(20) PRIMARY KEY,
    StudentName    VARCHAR(100) NOT NULL,
    Gender         VARCHAR(10),
    ContactNumber  VARCHAR(20),
    City           VARCHAR(50),
    CourseID       VARCHAR(20) FOREIGN KEY REFERENCES Courses(CourseID),
    EnrollmentDate DATE NOT NULL
);

CREATE TABLE Attendance (
    AttendanceID   INT IDENTITY(1,1) PRIMARY KEY,
    StudentID      VARCHAR(20) FOREIGN KEY REFERENCES Students(StudentID),
    ClassDate      DATE NOT NULL,
    Status         VARCHAR(10) NOT NULL   -- 'Present' or 'Absent'
);

CREATE TABLE Fees (
    PaymentID      INT IDENTITY(1,1) PRIMARY KEY,
    StudentID      VARCHAR(20) FOREIGN KEY REFERENCES Students(StudentID),
    AmountDue      DECIMAL(10,2) NOT NULL,
    AmountPaid     DECIMAL(10,2) NOT NULL DEFAULT 0,
    PaymentDate    DATE,
    PaymentStatus  VARCHAR(20)   -- 'Paid', 'Partial', 'Pending'
);

-- Indexes to support common query patterns
CREATE INDEX IX_Students_CourseID ON Students(CourseID);
CREATE INDEX IX_Attendance_StudentID ON Attendance(StudentID);
CREATE INDEX IX_Attendance_ClassDate ON Attendance(ClassDate);
CREATE INDEX IX_Fees_StudentID ON Fees(StudentID);
GO
