/* ============================================================
   04_stored_procedure.sql
   Reusable stored procedure: generates an at-risk student report
   (low attendance + pending fees) for a given course.
   ============================================================ */

USE CoachingCenterDB;
GO

CREATE OR ALTER PROCEDURE dbo.GetAtRiskStudents
    @CourseID VARCHAR(20),
    @AttendanceThreshold DECIMAL(5,2) = 75.00   -- default: flag below 75%
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        s.StudentName,
        c.CourseName,
        ROUND(
            SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0
            / NULLIF(COUNT(a.AttendanceID), 0), 2
        ) AS AttendancePercent,
        ISNULL(f.AmountDue - f.AmountPaid, 0) AS FeesOutstanding
    FROM Students s
    JOIN Courses c ON s.CourseID = c.CourseID
    JOIN Attendance a ON s.StudentID = a.StudentID
    LEFT JOIN Fees f ON s.StudentID = f.StudentID
    WHERE s.CourseID = @CourseID
    GROUP BY s.StudentName, c.CourseName, f.AmountDue, f.AmountPaid
    HAVING SUM(CASE WHEN a.Status = 'Present' THEN 1 ELSE 0 END) * 100.0
           / NULLIF(COUNT(a.AttendanceID), 0) < @AttendanceThreshold
    ORDER BY AttendancePercent ASC;
END;
GO

-- Example usage:
-- EXEC dbo.GetAtRiskStudents @CourseID = 'CRS-001', @AttendanceThreshold = 75.00;
