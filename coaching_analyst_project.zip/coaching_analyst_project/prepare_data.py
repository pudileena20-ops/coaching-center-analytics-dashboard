"""
prepare_data.py
-----------------
Helper script to reshape your real coaching-center export(s) into the
4 CSVs needed by 02_load_data.sql: Courses.csv, Students.csv,
Attendance.csv, Fees.csv.

Every coaching center's raw export looks different (one big Excel sheet,
separate registers, etc.) so this script is a STARTING POINT — you'll
likely need to adjust the column mapping below to match your actual file.

Usage:
    python prepare_data.py --input data/raw_export.xlsx --output_dir data/
"""

import argparse
import pandas as pd


def main(input_path: str, output_dir: str):
    # Read the raw file — adjust sheet_name if your Excel has multiple sheets
    if input_path.endswith(".xlsx") or input_path.endswith(".xls"):
        df = pd.read_excel(input_path)
    else:
        df = pd.read_csv(input_path)

    print("Columns found in your file:")
    print(list(df.columns))
    print("\nFirst few rows:")
    print(df.head())

    print("""
    ------------------------------------------------------------
    NEXT STEP: Open this script and edit the column mapping below
    to match the column names printed above. Each table needs its
    own set of columns pulled from your raw data.
    ------------------------------------------------------------
    """)

    # ---- EDIT THESE MAPPINGS to match your actual column names ----
    #
    # Example (uncomment and adjust once you see your real columns):
    #
    # students = df[["Student ID", "Student Name", "Gender", "Phone",
    #                "City", "Course ID", "Enrollment Date"]].drop_duplicates()
    # students.columns = ["StudentID", "StudentName", "Gender",
    #                      "ContactNumber", "City", "CourseID", "EnrollmentDate"]
    # students.to_csv(f"{output_dir}/Students.csv", index=False)
    #
    # courses = df[["Course ID", "Course Name", "Subject", "Instructor",
    #               "Batch Timing", "Start Date", "End Date"]].drop_duplicates()
    # courses.columns = ["CourseID", "CourseName", "Subject", "Instructor",
    #                     "BatchTiming", "StartDate", "EndDate"]
    # courses.to_csv(f"{output_dir}/Courses.csv", index=False)
    #
    # Attendance and Fees likely come from SEPARATE files/sheets (a daily
    # attendance register and a fee ledger) rather than the same sheet as
    # student info — load and map those separately the same way.

    print("Edit the mapping section in this script, then re-run it.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, help="Path to your raw data file (.xlsx or .csv)")
    parser.add_argument("--output_dir", required=True, help="Directory to save the 4 output CSVs")
    args = parser.parse_args()

    main(args.input, args.output_dir)
